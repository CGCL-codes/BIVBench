"""
Module for module extraction attacks with a common interface.
"""
from wrt.attacks.extraction.neural_cleanse import NeuralCleanse, NeuralCleansePartial, NeuralCleanseMulti
